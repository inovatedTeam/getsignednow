<?php echo e($data); ?>

