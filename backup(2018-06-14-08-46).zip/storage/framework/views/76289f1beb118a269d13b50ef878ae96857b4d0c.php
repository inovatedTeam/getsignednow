
<?php

$class = ($t->type == 'message' && $user_id == $t->user->id ? 'st2':'');

?>


<div class="chat-msg <?php echo e($class); ?>">
	<p><?php echo e($t->body); ?></p> 
	<span><?php echo e($t->created_at); ?></span>
</div>
