<?php 

	$settings = App\Models\AdminSettings::first();
	
	$percentage = round($response->donations()->sum('donation') / $response->goal * 100);
	
	if( $percentage > 100 ) {
		$percentage = 100;
	} else {
		$percentage = $percentage;
	}
	
	// All Donations
	$donations = $response->donations()->orderBy('id','desc')->paginate(10);
	
	// Updates
	$updates = $response->updates()->orderBy('id','desc')->paginate(1);
	
	if( str_slug( $response->title ) == '' ) {
		$slug_url  = '';
	} else {
		$slug_url  = '/'.str_slug( $response->title );
	}
	
	if( Auth::check() ) {
		// LIKE ACTIVE
	   $likeActive = App\Models\Like::where( 'user_id', Auth::user()->id )
	   ->where('campaigns_id',$response->id)
	   ->where('status','1')
	   ->first(); 
			 
       if( $likeActive ) {
       	  $textLike   = trans('misc.unlike');
		  $icoLike    = 'fa fa-heart';
		  $statusLike = 'active';
       } else {
       		$textLike   = trans('misc.like');
		    $icoLike    = 'fa fa-heart-o';
			$statusLike = '';
       }
	}
	
	// Deadline
	$timeNow = strtotime(Carbon\Carbon::now());
	
	if( $response->deadline != '' ) {
	    $deadline = strtotime($response->deadline);
		
		$date = strtotime($response->deadline);
	    $remaining = $date - $timeNow;
		
		$days_remaining = floor($remaining / 86400);	
	}
	
	// Network Type 
	 $network = App\Models\Networks::where( 'id', $response->user()->network_type_id )->first(); 
	
	// Country
	$country = App\Models\Countries::where('id', $response->user()->countries_id)->first();
    $profileId = (int)$response->user()->id+89066;
?>


<?php $__env->startSection('title'); ?><?php echo e($response->title.' - '); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<!-- Current locale and alternate locales -->
<meta property="og:locale" content="en_US" />
<meta property="og:locale:alternate" content="es_ES" />

<!-- Og Meta Tags -->
<link rel="canonical" href="<?php echo e(url("campaign/$response->id").'/'.str_slug($response->title)); ?>"/>
<meta property="og:site_name" content="<?php echo e($settings->title); ?>"/>
<meta property="og:url" content="<?php echo e(url("campaign/$response->id").'/'.str_slug($response->title)); ?>"/>
<meta property="og:image" content="<?php echo e(url('public/campaigns/large',$response->large_image)); ?>"/>

<meta property="og:title" content="<?php echo e($response->title); ?>"/>
<meta property="og:description" content="<?php echo e(strip_tags($response->description)); ?>"/>
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:image" content="<?php echo e(url('public/campaigns/large',$response->large_image)); ?>" />
<meta name="twitter:title" content="<?php echo e($response->title); ?>" />
<meta name="twitter:description" content="<?php echo e(strip_tags($response->description)); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="jumbotron md index-header jumbotron_set jumbotron-cover">
      <div class="container wrap-jumbotron position-relative">
      </div>
    </div>
    
<div class="container margin-bottom-40 padding-top-40">
	
	<?php if(session()->has('donation_cancel')): ?>
	<div class="alert alert-danger text-center btn-block margin-bottom-20  custom-rounded" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
								</button>
			<i class="fa fa-remove myicon-right"></i> <?php echo e(trans('misc.donation_cancel')); ?>

		</div>
		
		<?php endif; ?>
						
			<?php if(session('donation_success')): ?>
	<div class="alert alert-success text-center btn-block margin-bottom-20  custom-rounded" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
								</button>
			<i class="fa fa-check myicon-right"></i> <?php echo e(trans('misc.donation_success')); ?>

		</div>
		
		<?php endif; ?>

	
<!-- Col MD -->
<div class="col-md-8 margin-bottom-20"> 
	
	<div class="text-center margin-bottom-20">
		<img class="img-responsive img-rounded" style="display: inline-block;" src="<?php echo e(url('public/campaigns/large',$response->large_image)); ?>" />
</div>

<h1 class="font-default title-image none-overflow margin-bottom-20">
	 		<?php echo e($response->title); ?>

		</h1>
		
		<hr />
		
		<div class="row margin-bottom-30">
		<!--	<div class="col-md-3">-->
		<!--		<a class="btn btn-block btn-facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url('campaign',$response->id).'/'.str_slug($response->title)); ?>" target="_blank"><i class="fa fa-facebook myicon-right"></i> <?php echo e(trans('misc.share')); ?></a>-->
		<!--	</div>-->
			
		<!--	<div class="col-md-3">-->
		<!--		<a class="btn btn-twitter btn-block" href="https://twitter.com/intent/tweet?url=<?php echo e(url('campaign',$response->id)); ?>&text=<?php echo e(e( $response->title )); ?>" data-url="<?php echo e(url('campaign',$response->id)); ?>" target="_blank"><i class="fa fa-twitter myicon-right"></i> <?php echo e(trans('misc.tweet')); ?></a>-->
		<!--	</div>-->

		<!--<div class="col-md-3">-->
		<!--		<a class="btn btn-google-plus btn-block" href="https://plus.google.com/share?url=<?php echo e(url('campaign',$response->id).'/'.str_slug($response->title)); ?>" target="_blank"><i class="fa fa-google-plus myicon-right"></i> <?php echo e(trans('misc.share')); ?></a>-->
		<!--	</div>-->
			
		<!--	<div class="col-md-3">-->
		<!--		<a class="btn btn-default btn-block" data-toggle="modal" data-target="#embedModal" href="#"><i class="fa fa-code myicon-right"></i> <?php echo e(trans('misc.embed')); ?></a>-->
		<!--	</div>-->
			
			<div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" id="embedModal">
			  <div class="modal-dialog modal-lg" role="document">
			    <div class="modal-content">
			      <div class="modal-header headerModal">
				        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				        <h5 class="modal-title">
				        	<?php echo e(trans('misc.embed_title')); ?>

				        </h5>
				     </div><!-- Modal header -->
				     
				     <div class="modal-body">
				     	<div class="form-group">				     		
	                    	<input type="text" readonly="readonly" id="embedCode" value="<div style='width:350px;'><script src='<?php echo e(url('c',$response->id)); ?>/widget.js' type='text/javascript'></script></div>" class="form-control">
	                    </div><!-- /.form-group-->
				     </div>
				     
			    </div>
			  </div>
			</div>
			
		</div>

<ul class="nav nav-tabs nav-justified margin-bottom-20">
  <li class="active"><a href="#desc" aria-controls="home" role="tab" data-toggle="tab" class="font-default"><strong><?php echo e(trans('misc.story')); ?></strong></a></li>
	 		<li><a href="#updates" aria-controls="home" role="tab" data-toggle="tab" class="font-default"><strong><?php echo e(trans('misc.updates')); ?></strong> <span class="badge update-ico"><?php echo e(number_format($updates->total())); ?></span></a></li>
</ul>

<div class="tab-content">		
		<?php if( $response->description != '' ): ?>
		<div role="tabpanel" class="tab-pane fade in active description wordBreak"id="desc">
		<?php echo $response->description; ?>

		</div>
		<?php endif; ?>
		
		<div role="tabpanel" class="tab-pane fade description wordBreak margin-top-30" id="updates">
		
		<?php if( $updates->total() == 0 ): ?>	
			<span class="btn-block text-center">
	    			<i class="icon-history ico-no-result"></i>
	    		</span>
			<span class="text-center btn-block"><?php echo e(trans('misc.no_results_found')); ?></span>
			
			<?php else: ?>
			
			<?php $__currentLoopData = $updates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<?php echo $__env->make('includes.ajax-updates-campaign', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				
				 <?php echo e($updates->links('vendor.pagination.loadmore')); ?>

				
			<?php endif; ?>
			
		</div>
</div>

<div class="btn-block margin-top-20">
	<!--<div class="fb-comments"  data-width="100%" data-href="<?php echo e(url('campaign',$response->id).'/'.str_slug($response->title)); ?>" data-numposts="5"></div>-->
</div>

       
 </div><!-- /COL MD -->
 
 <div class="col-md-4">

<?php if( Auth::check() 
&&  isset($response->user()->id) 
&& Auth::user()->id == $response->user()->id 
&& !isset( $deadline ) 
&& $response->finalized == 0 
): ?> 	
 	<div class="row margin-bottom-20">
			<div class="col-md-12">
				<a class="btn btn-success btn-block margin-bottom-5" href="<?php echo e(url('edit/campaign',$response->id)); ?>"><?php echo e(trans('misc.edit_campaign')); ?></a>
			</div>
			<div class="col-md-12">
				<a class="btn btn-info btn-block margin-bottom-5" href="<?php echo e(url('update/campaign',$response->id)); ?>"><?php echo e(trans('misc.post_an_update')); ?></a>
			</div>
			<?php if( $response->donations()->count() == 0 ): ?>
			<div class="col-md-12">
				<a href="#" class="btn btn-danger btn-block" id="deleteCampaign" data-url="<?php echo e(url('delete/campaign',$response->id)); ?>"><?php echo e(trans('misc.delete_campaign')); ?></a>
			</div>
			<?php endif; ?>
		</div>

<?php elseif( Auth::check() 
&&  isset($response->user()->id) 
&& Auth::user()->id == $response->user()->id 
&& isset( $deadline ) 
&& $deadline > $timeNow 
&& $response->finalized == 0
): ?>		
		<div class="row margin-bottom-20">
			<div class="col-md-12">
				<a class="btn btn-success btn-block margin-bottom-5" href="<?php echo e(url('edit/campaign',$response->id)); ?>"><?php echo e(trans('misc.edit_campaign')); ?></a>
			</div>
			<div class="col-md-12">
				<a class="btn btn-info btn-block margin-bottom-5" href="<?php echo e(url('update/campaign',$response->id)); ?>"><?php echo e(trans('misc.post_an_update')); ?></a>
			</div>
			<div class="col-md-12">
				<a href="#" class="btn btn-danger btn-block" id="deleteCampaign" data-url="<?php echo e(url('delete/campaign',$response->id)); ?>"><?php echo e(trans('misc.delete_campaign')); ?></a>
			</div>
		</div>
		
		<?php endif; ?>

<?php if( isset($response->user()->id) ): ?>
<!-- Start Panel -->
    <div class="mainDetails">
        <div class="personalDetails">
            <img class="img-circle center-block profileImage" src="<?php echo e(url('public/avatar',$response->user()->avatar)); ?>" width="50" height="50" >
            <p class="userName">
                <?php echo e($response->user()->name); ?> <?php echo substr($response->user()->last_name,0,1).'.'; ?>

            </p>
            <p class="userCompany">
                <?php echo e($response->user()->company_name); ?>

            </p>
            <p class="profileId">
                <?php echo e(trans('misc.profile_id').': '.$profileId); ?>

            </p>
        </div>
        <ul class="detailsUl">
            <li class="detailsLi no-top-border">
                <i class="fa fa-hand-peace-o" aria-hidden="true"></i>
                <span class="personInfo">
                    <?php echo e($network->network_type); ?>

                </span>
            </li>
            <li class="detailsLi">
                <i class="fa fa-tags" aria-hidden="true"></i>
                <span class="personInfo"><?php echo e($response->category_name); ?></span>
            </li>
            <li class="detailsLi">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span class="personInfo">
                    <?php echo e($response->user()->state.', '.$country->country_name); ?>

                </span>
            </li>
            <li class="detailsLi">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span class="personInfo">
                    <?php if(Auth::guest()): ?>
                        <a href="http://www.raisethatmoney.com/login">Login to View</a>
                    <?php else: ?>
                        <!--<?php echo e($response->user()->mobile_number); ?>-->
                        <a href="http://www.raisethatmoney.com/">Upgrade to View</a>
                    <?php endif; ?>
                </span>
            </li>
            <li class="detailsLi">
                <i class="fa fa-link" aria-hidden="true"></i>
                <span class="personInfo">
                    <?php if(Auth::guest()): ?>
                        <a href="http://www.raisethatmoney.com/login">Login to View</a>
                    <?php else: ?>
                        <a href="http://www.raisethatmoney.com/">Upgrade to View</a>
                    <?php endif; ?>    
                </span>
            </li>
            <li class="detailsLi">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span class="personInfo">
                    <?php echo e(trans('misc.message').' '.$response->user()->name); ?>

                    <?php if( Auth::guest() || Auth::check() && Auth::user()->id != $response->user()->id ): ?>				    		
		    		<a href="#" title="<?php echo e(trans('misc.contact_organizer')); ?>" data-toggle="modal" data-target="#sendEmail">
		    				<!--<i class="fa fa-envelope myicon-right envelopeBlue"></i>-->
		    				<img src="<?php echo e(url('public/img/envelope.png')); ?>" class="absolutEnvelope">
		    		</a>
		    		<?php endif; ?>    
                </span>
            </li>
            
        </ul>
    </div>

<?php if($response->user()->network()->id == 1): ?>

<?php if( isset( $deadline ) && $deadline > $timeNow && $response->finalized == 0): ?>
 	<div class="btn-group btn-block margin-bottom-20 <?php if( Auth::check() && Auth::user()->id == $response->user()->id ): ?> display-none <?php endif; ?>" style="position:relative">
		<a href="<?php echo e(url('donate/'.$response->id.$slug_url)); ?>" class="btn btn-main btn-donate btn-lg btn-block custom-rounded">
			<?php echo e(trans('misc.donate_now')); ?>

			</a>
			<!--<i class="fa fa-heart-o absolutHeart" aria-hidden="true"></i>-->
			<img src="<?php echo e(url('public/img/donation.png')); ?>" class="absolutUsd">
		</div>
		
		<?php elseif( !isset( $deadline ) && $response->finalized == 0): ?>
		<div class="btn-group btn-block margin-bottom-20 <?php if( Auth::check() && Auth::user()->id == $response->user()->id ): ?> display-none <?php endif; ?>" style="position:relative">
		<a href="<?php echo e(url('donate/'.$response->id.$slug_url)); ?>" class="btn btn-main btn-donate btn-lg btn-block custom-rounded">
			<?php echo e(trans('misc.donate_now')); ?>

			</a>
			<!--<i class="fa fa-heart-o absolutHeart" aria-hidden="true"></i>-->
			<img src="<?php echo e(url('public/img/donation.png')); ?>" class="absolutUsd">
		</div>
		
		<?php else: ?>
		
		<div class="alert boxSuccess text-center btn-block margin-bottom-20  custom-rounded" role="alert">
			<i class="fa fa-lock myicon-right"></i> <?php echo e(trans('misc.campaign_ended')); ?>

		</div>
		
		<?php endif; ?>
<?php endif; ?>
<?php else: ?>
<div class="alert boxSuccess text-center btn-block margin-bottom-20  custom-rounded" role="alert">
			<i class="fa fa-lock myicon-right"></i> <?php echo e(trans('misc.campaign_ended')); ?>

		</div>		
<?php endif; ?>



	<div class="panel panel-default">
		<div class="panel-body text-center">
	<?php if( Auth::check() ): ?>
		<a href="#" class="btnLike likeButton <?php echo e($statusLike); ?>" data-id="<?php echo e($response->id); ?>" data-like="<?php echo e(trans('misc.like')); ?>" data-unlike="<?php echo e(trans('misc.unlike')); ?>">
			<h3 class="btn-block text-center margin-zero"><i class="<?php echo e($icoLike); ?>"></i> <span id="countLikes"><?php echo e(App\Helper::formatNumber($response->likes()->count())); ?></span></h3>
		</a>
		<?php else: ?>
		
		<a href="<?php echo e(url('login')); ?>" class="btnLike">
			<h3 class="btn-block text-center margin-zero"><i class="fa fa-heart-o"></i> <span id="countLikes"><?php echo e(App\Helper::formatNumber($response->likes()->count())); ?></span></h3>
		</a>
		
		<?php endif; ?>
	   </div>
	</div>

	<?php if( $response->deadline != '' ): ?>		
		<!-- Start Panel -->
	<div class="panel panel-default">
		<div class="panel-body">
			<h4 class="margin-zero text-center" data-date="<?php echo e(date('M d, Y', strtotime($response->deadline) )); ?>">
			
			<?php if( $days_remaining > 0 ): ?>	
				<i class="fa fa-clock-o myicon-right"></i> 
				<strong> <?php echo e($days_remaining); ?> <?php echo e(trans('misc.days_left')); ?> </strong> 
				<?php elseif( $days_remaining == 0 ): ?>
				  
				  <i class="fa fa-clock-o myicon-right"></i> 
				<strong> <?php echo e(trans('misc.last_day')); ?> </strong>
				
				<?php else: ?>
				
				 <i class="fa fa-lock myicon-right"></i> 
				<strong> <?php echo e(trans('misc.no_time_anymore')); ?> </strong>
				
				<?php endif; ?>
			
				</h4>
		</div>
	</div><!-- End Panel -->
	<?php endif; ?>
	
	<?php if( $response->featured == 1 ): ?>		
		<!-- Start Panel -->
	<div class="panel panel-default">
		<div class="panel-body text-center">
			<h4 class="margin-zero font-default"><i class="fa fa-trophy myicon-right featured-icon"></i> <strong><?php echo e(trans('misc.featured_campaign')); ?></strong></h4>
		</div>
	</div><!-- End Panel -->
	<?php endif; ?>
	
	<?php if( $response->user()->network()->id == 1): ?>


	<!-- Start Panel -->
	<div class="panel panel-default">
		<div class="panel-body">
			<h3 class="btn-block margin-zero" style="line-height: inherit;">
				<strong class="font-default"><?php echo e($settings->currency_symbol.number_format($response->donations()->sum('donation'))); ?></strong> 
				<small><?php echo e(trans('misc.of')); ?> <?php echo e($settings->currency_symbol.number_format($response->goal)); ?> <?php echo e(strtolower(trans('misc.goal'))); ?></small>
				</h3>
				
				<span class="progress margin-top-10 margin-bottom-10">
					<span class="percentage" style="width: <?php echo e($percentage); ?>%" aria-valuemin="0" aria-valuemax="100" role="progressbar"></span>
				</span>
				
				<small class="btn-block margin-bottom-10 text-muted">
					<?php echo e($percentage); ?>% <?php echo e(trans('misc.raised')); ?> <?php echo e(trans('misc.by')); ?> <?php echo e(number_format($response->donations()->count())); ?> <?php echo e(trans_choice('misc.donation_plural',$response->donations()->count())); ?>

				</small>
				
				<?php if( $response->categories_id != '' ): ?>
				<?php if( isset( $response->category->id ) && $response->category->mode == 'on' ): ?>
				<small class="btn-block">
					<a href="<?php echo e(url('category',$response->category->slug)); ?>" title="<?php echo e($response->category->name); ?>">
						<i class="icon-tag myicon-right"></i> <?php echo e(str_limit($response->category->name, 18, '...')); ?>

						</a>
				</small>
				<?php endif; ?>
				<?php endif; ?>
										
		</div>
	</div><!-- End Panel -->
	<?php endif; ?>
<?php if($response->user()->network()->id == 1): ?>		
<ul class="list-group" id="listDonations">
       <li class="list-group-item"><i class="fa fa-clock-o myicon-right"></i> <strong><?php echo e(trans('misc.recent_donations')); ?></strong> (<?php echo e(number_format($response->donations()->count())); ?>)</li>
       
    <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    
    <?php 
    $letter = str_slug(mb_substr( $donation->fullname, 0, 1,'UTF8')); 
    
	if( $letter == '' ) {
		$letter = 'N/A';
	} 
	
	if( $donation->anonymous == 1 ) {
		$letter = 'N/A';
		$donation->fullname = trans('misc.anonymous');
	}
    ?>
    
     <?php echo $__env->make('includes.listing-donations', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     
       	 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
       	 
       	 <?php if( $response->donations()->count() == 0 ): ?>
       	 <li class="list-group-item"><?php echo e(trans('misc.no_donations')); ?></li>
       	 <?php endif; ?>
       	 
       	 <?php echo e($donations->links('vendor.pagination.loadmore')); ?>

       	        	 
	</ul>
<?php endif; ?>	
	<?php if( Auth::check() &&  isset($response->user()->id) && Auth::user()->id != $response->user()->id  ): ?>	
	<div class="btn-block text-center">
		<a href="<?php echo e(url('report/campaign', $response->id)); ?>/<?php echo e($response->user()->id); ?>"><i class="icon-warning myicon-right"></i> <?php echo e(trans('misc.report')); ?></a>
	</div>
	<?php endif; ?>

<?php if(  isset($response->user()->id) ): ?>	
<div class="modal fade" id="sendEmail" tabindex="-1" role="dialog" aria-hidden="true">
     		<div class="modal-dialog">
     			<div class="modal-content"> 
     				<div class="modal-header headerModal">
				        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				        
				        <h4 class="modal-title text-center" id="myModalLabel">
				        	<?php echo e(trans('misc.contact_organizer')); ?>

				        	</h4>
				     </div><!-- Modal header -->
				     
				      <div class="modal-body listWrap text-center center-block modalForm">
				    
				    <!-- form start -->
			    <form method="POST" class="margin-bottom-15" action="<?php echo e(url('contact/organizer')); ?>" enctype="multipart/form-data" id="formContactOrganizer">
			    	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			    	<input type="hidden" name="id" value="<?php echo e($response->user()->id); ?>">  	
				    
				    <!-- Start Form Group -->
                    <div class="form-group">
                    	<input type="text" required="" name="name" class="form-control" placeholder="<?php echo e(trans('users.name')); ?>">
                    </div><!-- /.form-group-->
                    
                    <!-- Start Form Group -->
                    <div class="form-group">
                    	<input type="text" required="" name="email" class="form-control" placeholder="<?php echo e(trans('auth.email')); ?>">
                    </div><!-- /.form-group-->
                    
                    <!-- Start Form Group -->
                    <div class="form-group">
                    	<textarea name="message" rows="4" class="form-control" placeholder="<?php echo e(trans('misc.message')); ?>"></textarea>
                    </div><!-- /.form-group-->
                   						
                    <!-- Alert -->
                    <div class="alert alert-danger display-none" id="dangerAlert">
							<ul class="list-unstyled text-left" id="showErrors"></ul>
						</div><!-- Alert -->

                  
                   <button type="submit" class="btn btn-lg btn-main custom-rounded" id="buttonFormSubmit"><?php echo e(trans('misc.send_message')); ?></button>
                   
                    </form>
                    
                                        <!-- Alert -->
                    <div class="alert alert-success display-none" id="successAlert">
							<ul class="list-unstyled" id="showSuccess"></ul>
						</div><!-- Alert -->


				      </div><!-- Modal body -->
     				</div><!-- Modal content -->
     			</div><!-- Modal dialog -->
     		</div><!-- Modal -->
     		<?php endif; ?>
     		
 </div><!-- /COL MD -->
 
 </div><!-- container wrap-ui -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">

$("#embedCode").click(function() {
	var $this = $(this);
    $this.select();
		});
		
textTruncate('#desc', ' <?php echo e(trans("misc.view_more")); ?>');

$(document).on('click','#updates .loadPaginator', function(r){
	r.preventDefault();
	 $(this).remove();
			$('<a class="list-group-item text-center loadMoreSpin"><i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw"></i></a>').appendTo( "#updates" );
			
			var page = $(this).attr('href').split('page=')[1];
			$.ajax({
				url: '<?php echo e(url("ajax/campaign/updates")); ?>?id=<?php echo e($response->id); ?>&page=' + page
			}).done(function(data){
				if( data ) {
					$('.loadMoreSpin').remove();
					
					$( data ).appendTo( "#updates" );
					jQuery(".timeAgo").timeago();
					Holder.run({images:".holderImage"})
				} else {
					bootbox.alert( "<?php echo e(trans('misc.error')); ?>" );
				}
				//<**** - Tooltip
			});
	});

$(document).on('click','#listDonations .loadPaginator', function(e){
			e.preventDefault();
			$(this).remove();
			//$('<li class="list-group-item position-relative spinner spinnerList loadMoreSpin"></li>').appendTo( "#listDonations" )
			$('<a class="list-group-item text-center loadMoreSpin"><i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw"></i></a>').appendTo( "#listDonations" );
			
			var page = $(this).attr('href').split('page=')[1];
			$.ajax({
				url: '<?php echo e(url("ajax/donations")); ?>?id=<?php echo e($response->id); ?>&page=' + page
			}).done(function(data){
				if( data ) {
					$('.loadMoreSpin').remove();
					
					$( data ).appendTo( "#listDonations" );
					jQuery(".timeAgo").timeago();
					Holder.run({images:".holderImage"})
				} else {
					bootbox.alert( "<?php echo e(trans('misc.error')); ?>" );
				}
				//<**** - Tooltip
			});
		});
		
		<?php if( Auth::check() ): ?> 
				
$("#deleteCampaign").click(function(e) {
   	e.preventDefault();
   	   	
   	var element = $(this);
	var url     = element.attr('data-url');
	
	element.blur();
	
	swal(
		{   title: "<?php echo e(trans('misc.delete_confirm')); ?>",  
		 text: "<?php echo e(trans('misc.confirm_delete_campaign')); ?>",  
		  type: "warning",   
		  showLoaderOnConfirm: true,
		  showCancelButton: true,   
		  confirmButtonColor: "#DD6B55",  
		   confirmButtonText: "<?php echo e(trans('misc.yes_confirm')); ?>",   
		   cancelButtonText: "<?php echo e(trans('misc.cancel_confirm')); ?>",  
		    closeOnConfirm: false,  
		    }, 
		    function(isConfirm){  
		    	 if (isConfirm) {     
		    	 	window.location.href = url;
		    	 	}
		    	 });
		    	 
		 });
		 
		 <?php if(session('noty_error')): ?>
    		swal({   
    			title: "<?php echo e(trans('misc.error_oops')); ?>",   
    			text: "<?php echo e(trans('misc.already_sent_report')); ?>",   
    			type: "error",   
    			confirmButtonText: "<?php echo e(trans('users.ok')); ?>" 
    			});
   		 <?php endif; ?>
   		 
   		 <?php if(session('noty_success')): ?>
    		swal({   
    			title: "<?php echo e(trans('misc.thanks')); ?>",   
    			text: "<?php echo e(trans('misc.send_success')); ?>",   
    			type: "success",   
    			confirmButtonText: "<?php echo e(trans('users.ok')); ?>" 
    			});
   		 <?php endif; ?>
		
		<?php endif; ?>
		 
</script>

<?php $__env->stopSection(); ?>
<?php  session()->forget('donation_cancel')  ?>
<?php  session()->forget('donation_success')  ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>