<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('public/plugins/iCheck/all.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('public/css/main.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrap-loader">
		<i class="fa fa-cog fa-spin fa-3x fa-fw cog-loader"></i>
		<i class="fa fa-cog fa-spin fa-3x fa-fw cog-loader-small"></i>
	</div>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h4>
            <?php echo e(trans('admin.admin')); ?> 
            	<i class="fa fa-angle-right margin-separator"></i> 
            		<?php echo e(trans('admin.edit')); ?>

            		
            		<i class="fa fa-angle-right margin-separator"></i> 
            		<?php echo e($data->name); ?>

          </h4>

        </section>

        <!-- Main content -->
        <section class="content">

        	<div class="content">
        		
       <div class="row">
       	
       	<div class="col-md-9">
    
        	<div class="box box-danger">
                <div class="box-header with-border">
                  <h3 class="box-title"><?php echo e(trans('admin.edit')); ?></h3>
                </div><!-- /.box-header -->
               
                <!-- form start -->
                <form class="form-horizontal" method="POST" action="<?php echo e(url('panel/admin/members/'.$data->id)); ?>" enctype="multipart/form-data">
                	
                	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                	<input type="hidden" name="_method" value="PUT">	
			
					<?php echo $__env->make('errors.errors-forms', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <?php if(count($errors) > 0): ?>
                                            <?php $err = $errors->default->toArray();?> 
                                        <?php endif; ?>
                                        
                <!-- Start Box Body -->
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-2 control-label"><?php echo e(trans('admin.network')); ?></label>
                      <div class="col-sm-10">
                        <select name="network_type_id" class="form-control <?php echo e(((isset($err['network_type_id'])) ? " form-error" : "")); ?>" >
                            <option value="" disabled></option>
                                <?php $__currentLoopData = App\Models\Networks::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 	
                                    <option <?php if( $data->network_type_id == $network->id ): ?> selected="selected" <?php endif; ?> value="<?php echo e($network->id); ?>"><?php echo e($network->network_type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                          </select>
                      </div>
                    </div>
                  </div>
                  <!-- /.box-body -->
                 <!-- Start Box Body -->
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-2 control-label"><?php echo e(trans('admin.first_name')); ?></label>
                      <div class="col-sm-10">
                        <input type="text" value="<?php echo e($data->name); ?>" name="first_name" class="form-control <?php echo e(((isset($err['first_name'])) ? " form-error" : "")); ?>" placeholder="<?php echo e(trans('admin.first_name')); ?>">
                      </div>
                    </div>
                  </div><!-- /.box-body -->
                 
                  <!-- Start Box Body -->
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-2 control-label"><?php echo e(trans('admin.last_name')); ?></label>
                      <div class="col-sm-10">
                        <input type="text" value="<?php echo e($data->last_name); ?>" name="last_name" class="form-control <?php echo e(((isset($err['last_name'])) ? " form-error" : "")); ?>" placeholder="<?php echo e(trans('admin.last_name')); ?>">
                      </div>
                    </div>
                  </div><!-- /.box-body -->
                  
                  <!-- Start Box Body -->
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-2 control-label"><?php echo e(trans('admin.company_name')); ?></label>
                      <div class="col-sm-10">
                        <input type="text" value="<?php echo e($data->company_name); ?>" name="company_name" class="form-control" placeholder="<?php echo e(trans('admin.company_name')); ?>">
                      </div>
                    </div>
                  </div><!-- /.box-body -->
                  
                  <!-- Start Box Body -->
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-2 control-label"><?php echo e(trans('admin.mobile_number')); ?></label>
                      <div class="col-sm-10">
                        <input type="text" value="<?php echo e($data->mobile_number); ?>" name="mobile_number" class="form-control <?php echo e(((isset($err['mobile_number'])) ? " form-error" : "")); ?>" placeholder="<?php echo e(trans('admin.mobile_number')); ?>">
                      </div>
                    </div>
                  </div><!-- /.box-body -->                                    
                  
                  <!-- Start Box Body -->
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-2 control-label"><?php echo e(trans('auth.email')); ?></label>
                      <div class="col-sm-10">
                        <input type="text" value="<?php echo e($data->email); ?>" name="email" class="form-control <?php echo e(((isset($err['email'])) ? " form-error" : "")); ?>" placeholder="<?php echo e(trans('auth.email')); ?>">
                      </div>
                    </div>
                  </div><!-- /.box-body -->
                  
                  <!-- Start Box Body -->
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-2 control-label"><?php echo e(trans('admin.state')); ?></label>
                      <div class="col-sm-10">
                        <input type="text" value="<?php echo e($data->state); ?>" name="state" class="form-control <?php echo e(((isset($err['state'])) ? " form-error" : "")); ?>" placeholder="<?php echo e(trans('admin.state')); ?>">
                      </div>
                    </div>
                  </div><!-- /.box-body -->
                  
                  <!-- Start Box Body -->
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-2 control-label"><?php echo e(trans('admin.country')); ?></label>
                      <div class="col-sm-10">
                        <select name="countries_id" class="form-control <?php echo e(((isset($err['countries_id'])) ? " form-error" : "")); ?>" >
                      		<option value=""><?php echo e(trans('misc.select_your_country')); ?></option>
                                <?php $__currentLoopData = App\Models\Countries::orderBy('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 	
                                    <option <?php if( $data->countries_id == $country->id ): ?> selected="selected" <?php endif; ?> value="<?php echo e($country->id); ?>"><?php echo e($country->country_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                          </select>
                      </div>
                    </div>
                  </div>
                  <!-- /.box-body -->
                  
                  <!-- Start Box Body -->
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-2 control-label"><?php echo e(trans('admin.role')); ?></label>
                      <div class="col-sm-10">
                        <select name="role" class="form-control" >
                      		<option <?php if($data->role == 'normal'): ?> selected="selected" <?php endif; ?> value="normal"><?php echo e(trans('admin.normal')); ?> <?php echo e(trans('admin.normal_user')); ?></option>
                      		<option <?php if($data->role == 'admin'): ?> selected="selected" <?php endif; ?> value="admin"><?php echo e(trans('misc.admin')); ?></option>
                          </select>
                      </div>
                    </div>
                  </div><!-- /.box-body -->
                  
                  <!-- Start Box Body -->
                  <div class="box-body">
                    <div class="form-group">
                      <label class="col-sm-2 control-label"><?php echo e(trans('auth.password')); ?></label>
                      <div class="col-sm-10">
                        <input type="password" value="" name="password" class="form-control" placeholder="<?php echo e(trans('admin.password_no_change')); ?>">
                      </div>
                    </div>
                  </div><!-- /.box-body -->
                  
                  <div class="box-footer">
                  	 <a href="<?php echo e(url('panel/admin/members')); ?>" class="btn btn-default"><?php echo e(trans('admin.cancel')); ?></a>
                    <button type="submit" class="btn btn-success pull-right"><?php echo e(trans('admin.save')); ?></button>
                  </div><!-- /.box-footer -->
                </form>
              </div>
              
        </div><!-- /. col-md-9 -->
        
        <div class="col-md-3">
        	<!-- *********** AVATAR ************* -->
		
		<form action="<?php echo e(url('panel/admin/member/uploadAvatar')); ?>" method="POST" id="formAvatar" accept-charset="UTF-8" enctype="multipart/form-data">
    		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    		
    		<div class="block-block text-center center">
        		<img src="<?php echo e(asset('public/avatar').'/'.$data->avatar); ?>" width="100%" class="avatarUser thumbnail img-responsive">
        	</div>
    		
    		<div class="text-center">
    			<button type="button" class="btn btn-default btn-border btn-sm" id="avatar_file" style="margin-bottom: 10px;">
	    		<i class="icon-camera myicon-right"></i> <?php echo e(trans('misc.change_avatar')); ?>

	    		</button>
	    		<input type="hidden" name="user_id" value="<?php echo e($data->id); ?>">
	    		<input type="file" name="photo" id="uploadAvatar" accept="image/*" style="visibility: hidden;">
    		</div>
			
		    </form>
			<!-- *********** AVATAR ************* -->
			
        	        	        	
        	<ol class="list-group">
			<li class="list-group-item"> <?php echo e(trans('admin.registered')); ?> <span class="pull-right color-strong"><?php echo e(date('d M, y', strtotime($data->date))); ?></span></li>
			
			<li class="list-group-item"> <?php echo e(trans('admin.status')); ?> <span class="pull-right color-strong"><?php echo e(ucfirst($data->status)); ?></span></li>
			
			<li class="list-group-item"> <?php echo e(trans('misc.country')); ?> <span class="pull-right color-strong"><?php if( $data->countries_id != '' ): ?> <?php echo e($data->country()->country_name); ?> <?php else: ?> <?php echo e(trans('admin.not_established')); ?> <?php endif; ?></span></li>
			
			<li class="list-group-item"> <?php echo e(trans_choice('misc.campaigns_plural', 0)); ?> <strong class="pull-right color-strong"><?php echo e(App\Helper::formatNumber( $data->campaigns()->count() )); ?></strong></li>
                        
                        <li class="list-group-item"> <?php echo e(trans_choice('misc.registration_ip', 0)); ?> <strong class="pull-right color-strong"><?php if( $data->registration_ip_address != '' || $data->registration_ip_address != null): ?> <?php echo e($data->registration_ip_address); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?></strong></li>
                        
                        <li class="list-group-item"> <?php echo e(trans_choice('misc.last_login_ip', 0)); ?> <strong class="pull-right color-strong"><?php if( $data->registration_ip_address != '' || $data->last_login_ip_address != null): ?> <?php echo e($data->last_login_ip_address); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?></strong></li>
					</ol>
		
		<div class="block-block text-center">
		<?php echo Form::open([
			            'method' => 'DELETE',
			            'route' => ['user.destroy', $data->id],
			            'class' => 'displayInline'
				        ]); ?>

	            	<?php echo Form::submit(trans('admin.delete'), ['data-url' => $data->id, 'class' => 'btn btn-lg btn-danger btn-block margin-bottom-10 actionDelete']); ?>

	        	<?php echo Form::close(); ?>

	        </div>
		
		</div><!-- col-md-3 -->        			        		
        		
        		</div><!-- /.row -->
        		
        	</div><!-- /.content -->
        	
          <!-- Your Page Content Here -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
	
	<!-- icheck -->
	<script src="<?php echo e(asset('public/plugins/iCheck/icheck.min.js')); ?>" type="text/javascript"></script>
	<script src="<?php echo e(asset('public/js/jquery.form.js')); ?>" type="text/javascript"></script>
<script type="text/javascript">
	$("input").on("click", function(){
        if($(this).hasClass('form-error')){
            $(this).removeClass('form-error');
        }
    });
    $("select").on("change", function(){
        if($(this).hasClass('form-error')){
            $(this).removeClass('form-error');
        }
    });
	$(".actionDelete").click(function(e) {
   	e.preventDefault();
   	   	
   	var element = $(this);
	var id     = element.attr('data-url');
	var form    = $(element).parents('form');
	
	element.blur();
	
	swal(
		{   title: "<?php echo e(trans('misc.delete_confirm')); ?>",  
		text: "<?php echo e(trans('admin.delete_user_confirm')); ?>",
		  type: "warning", 
		  showLoaderOnConfirm: true,
		  showCancelButton: true,   
		  confirmButtonColor: "#DD6B55",  
		   confirmButtonText: "<?php echo e(trans('misc.yes_confirm')); ?>",   
		   cancelButtonText: "<?php echo e(trans('misc.cancel_confirm')); ?>",  
		    closeOnConfirm: false, 
		    }, 
		    function(isConfirm){  
		    	 if (isConfirm) {   
		    	 	form.submit(); 
		    	 	//$('#form' + id).submit();
		    	 	}
		    	 });
		    	 
		    	 
		 });
		 
		//Flat red color scheme for iCheck
        $('input[type="radio"]').iCheck({
          radioClass: 'iradio_flat-red'
        });
		//<<<<<<<=================== * UPLOAD AVATAR  * ===============>>>>>>>//
	
	$(document).on('click','#avatar_file',function () {
		var _this = $(this);
	    $("#uploadAvatar").trigger('click');
    	     _this.blur();
	});
    $(document).on('change', '#uploadAvatar', function(){
        $('.wrap-loader').show();
        
       (function(){
    	 $("#formAvatar").ajaxForm({
    	 dataType : 'json',	
    	 success:  function(e){
    	 if( e ){
            if( e.success == false ){
    		$('.wrap-loader').hide();
    		
    		var error = '';
                            for($key in e.errors){
                            	error += '' + e.errors[$key] + '';
                            }
    		swal({   
        			title: "<?php echo e(trans('misc.error_oops')); ?>",   
        			text: ""+ error +"",   
        			type: "error",   
        			confirmButtonText: "<?php echo e(trans('users.ok')); ?>" 
        			});
    		
    			$('#uploadAvatar').val('');
    
    		} else {
    			
    			$('#uploadAvatar').val('');
    			$('.avatarUser').attr('src',e.avatar);
    			$('.wrap-loader').hide();
    		}
    		
    		}//<-- e
    			else {
    				$('.wrap-loader').hide();
    				swal({   
        			title: "<?php echo e(trans('misc.error_oops')); ?>",   
        			text: '<?php echo e(trans("misc.error")); ?>',   
        			type: "error",   
        			confirmButtonText: "<?php echo e(trans('users.ok')); ?>" 
        			});
        			
    				$('#uploadAvatar').val('');
    			}
    		   }//<----- SUCCESS
    		}).submit();
        })(); //<--- FUNCTION %
    });//<<<<<<<--- * ON * --->>>>>>>>>>>
//<<<<<<<=================== * UPLOAD AVATAR  * ===============>>>>>>>//
	</script>
	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>