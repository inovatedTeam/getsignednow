<!-- Bootstrap core JavaScript 
    ================================================== -->    
    <script src="<?php echo e(asset('public/plugins/jQuery/jQuery-2.1.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jquery.easing.1.3.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jquery-ui-1.10.3.custom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jquery.ui.touch-punch.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jquery.autosize.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jqueryTimeago.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/bootbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/count.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/functions.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jquery.form.js')); ?>"></script>
    <script src="<?php echo e(asset('public/plugins/sweetalert/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/holder.min.js')); ?>"></script>
    
    